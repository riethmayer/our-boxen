# Chromedriver Puppet Module for Boxen

Installs chromedriver.

## Usage

```
include chromedriver 
```

## Required Puppet Modules

* `boxen`
* `homebrew`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
